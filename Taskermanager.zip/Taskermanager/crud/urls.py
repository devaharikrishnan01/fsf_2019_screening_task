"""crud URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from first.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', sayhi),
    path('home/', sayhi),
    path('register/', register),
    path('check/<str:username>', checkuser),
    path('signup/', signup),
    path('login/', login),
    path('ang/', angular),
    path('logout/', logout),
    path('login_action/', login_action),
    path('savetodo/', savetodo),
    path('personal_done/<int:id>', personal_done),
    path('teams/', createteams),
    path('teams/<int:t_id>', createteams),
    path('createteam/', addteams),
    path('viewteams/', viewteams),  
    path('teamprofile/<str:teamname>', teamprofile),
    path('team/<str:teamname>',team),
    path('addgrouptask/',addgrouptask),
    path('addmember/',addmember),
    path('change_task_status/<str:status>/<int:task_id>/<str:team>',change_task_status),
    path('reply/',reply),
    path('checkusername/<str:name>',checkusername),
    path('checkteamname/<str:team_name>',checkteamname),
    path('getallusername/<str:name>',getallusername),
    path('addtask/<str:name>',addtask),
    path('addtask/<str:name>/<int:taskid>',addtask),
    path('assignteamtask/', assignteamtask),
    path('delete_assignee_from_task/<int:task_id>/<str:assignee>', del_assignee),
    path('deletetask/<int:taskid>', deletetask),
    path('getteamtaskdetails/<int:taskid>', getteamtaskdetails),
    path('exit/<str:name>/<str:team_name>',exitteam),
    path('deleteteam/<str:team_name>', deleteteam),
    path('getteamdetails/<int:team_id>', getteamdetails),
    path('dummy/', dummy),
    path('profile/', profile),
    path('changepassword/', changepassword),
    path('changepass/', changepass),
    path('addteammember/<str:teamname>', addteammember),
]
