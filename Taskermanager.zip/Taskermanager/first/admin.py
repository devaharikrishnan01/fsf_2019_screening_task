from django.contrib import admin

# Register your models here.
from first.models import *

admin.site.register(user)
admin.site.register(personal_todo)
admin.site.register(team_details)
admin.site.register(team_members)
admin.site.register(teamtasks)
admin.site.register(teamtaskmembers)
admin.site.register(commentreply)